package com.example.clarityfinal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
